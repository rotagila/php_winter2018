<?php

$baseConfig['appName'] = 'LightMVC Framework';

/*$baseConfig['doctrine']['DBAL']['CONN_NAME'] = [
    'driver'   => 'pdo_mysql',
    'host'     => '127.0.0.1',
    'user'     => 'USERNAME',
    'password' => 'PASSWORD',
    'dbname'   => 'DBNAME',
];*/

/*$baseConfig['doctrine']['ORM']['CONN_NAME'] = [
    'driver'   => 'pdo_mysql',
    'host'     => '127.0.0.1',
    'user'     => 'USERNAME',
    'password' => 'PASSWORD',
    'dbname'   => 'DBNAME',
];*/
