<?php

// This file should contain your second controller.