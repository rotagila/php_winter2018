**FizzBuzzTest**
-------------------------------------

To run the tests after you ``cd`` into this directory:

```$ php composer.phar self-update```

```$ php composer.phar install```

```$ php composer.phar test```

> I had some fun doing two versions of the
> **FizzBuzz** class' code following the
> principles of two different programming
> styles : functional and imperative. The
> functional style allows for an additional
> test to validate the link between the
> divider and the replacement string.
