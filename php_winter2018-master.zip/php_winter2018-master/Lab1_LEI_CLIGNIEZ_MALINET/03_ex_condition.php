<?php

$valueA = 5;
$valueB = 3;

if ($valueA > $valueB) {
    echo 'ValueA is greater than ValueB <br />' . PHP_EOL;
}
else if ($valueA === $valueB) {//identical
    echo 'ValueA is equal to ValueB <br />' . PHP_EOL;
}