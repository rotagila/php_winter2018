<?php

$a = 2;

$b = '1day';

// math operator
echo $a + $b . '<br />' . PHP_EOL;

//string operator
echo $a . $b . '<br />' . PHP_EOL;
