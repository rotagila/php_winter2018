<?php

function getTotal($n1, $n2)
{
	return $n1 + $n2;
}

echo getTotal(25.99, 20.00) . PHP_EOL;