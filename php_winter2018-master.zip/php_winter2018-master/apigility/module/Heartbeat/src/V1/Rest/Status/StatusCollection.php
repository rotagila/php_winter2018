<?php
namespace Heartbeat\V1\Rest\Status;

use Zend\Paginator\Paginator;

class StatusCollection extends Paginator
{
}
