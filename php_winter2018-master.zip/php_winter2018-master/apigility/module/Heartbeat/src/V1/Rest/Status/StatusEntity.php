<?php
namespace Heartbeat\V1\Rest\Status;

class StatusEntity
{
}
