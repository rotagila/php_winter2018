<?php

$geo = ['country' => 'USA',
		6 => 47.005,
		'long',
		5 => 'eagle'
];

$geo[] = 'North America';

var_dump($geo);