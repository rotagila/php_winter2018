<?php

// This file should contain your second controller.

class controller2{
    public function __construct()
    {
        echo "Hello from controller2";
    }
}