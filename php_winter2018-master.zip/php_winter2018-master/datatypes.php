<?php

var_dump(1 + 1);

var_dump(1 + '1');

var_dump(1 + '1d');

var_dump(1 + 'd1');

var_dump('1' . 'd1');

var_dump(1 . 'd1');

var_dump((int) '1');

var_dump((string) 1);

var_dump(0 && 1);

var_dump(1 || 1);

var_dump(1 ^ 1);

var_dump(1 == '1');

var_dump(1 === '1');