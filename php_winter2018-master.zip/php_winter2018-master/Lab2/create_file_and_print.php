<?php

// Create a file by putting your name in it

// Read the newly created file's content and print it to screen