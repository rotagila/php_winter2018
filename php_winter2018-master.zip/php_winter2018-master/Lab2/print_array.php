<?php

// Create an array

// Print the array to screen using a foreach loop