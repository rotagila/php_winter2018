<?php

// Create an array
$arr = [];

$arr[] = "tibo";
$arr[] = "gregoire";
$arr[] = "fabiem";

// Print the array to screen using a foreach loop
foreach ($arr as $item) {
    echo "$item".PHP_EOL;
}