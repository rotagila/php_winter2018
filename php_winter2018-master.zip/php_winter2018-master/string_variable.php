<?php

$myName = 'Andrew';

echo 'Hello, World' . PHP_EOL;

echo "This is a message from $myName" . PHP_EOL;