<?php

$a = '12345';
var_dump($a);

$b = 'day12345day';
var_dump($a, $b);

$c = $a + $b;
var_dump($a, $b, $c);
