<?php

echo 'This is a message from test.php!';