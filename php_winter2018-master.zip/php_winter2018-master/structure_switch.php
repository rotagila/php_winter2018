<?php

$a = 'red';

// No default CASE!!!
switch ($a) {
	case "red":
		echo "Your favorite color is red";
		break;
	case "blue":
		echo "Your favorite color is blue";
		break;
	case "orange":
		echo "Your favorite color is orange";
		break;
	case "yellow":
		echo "Your favorite color is yellow";
		break;
}