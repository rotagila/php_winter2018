<?php

echo "10" + "0.6", 44 . 1 . PHP_EOL;

/*
 * Return value is:
 *
 * Please explain:
 *
 */