<?php

$valueA = 5;
$valueB = 3;

echo 'ValueA is greater than ValueB <br />' . PHP_EOL;
echo 'ValueA is equal to ValueB <br />' . PHP_EOL;