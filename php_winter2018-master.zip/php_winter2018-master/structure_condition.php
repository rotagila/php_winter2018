<?php

$dayOfWeek = 'Friday';
//$dayOfWeek = 'Monday';

if ($dayOfWeek === 'Friday') {
	echo 'See you on Monday';
} else {
	echo 'It\'s not Friday yet!';
}