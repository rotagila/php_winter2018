<?php

// "Hello World!" program

/*
 * On two lines:
 * print "Hello World!" to the screen (STDOUT),
 * print a greetings message with your first name in it.
 *
 * Your first name must be stored in a variable.
 *
 */

$myName = "Mike";
echo "Hello World!". PHP_EOL;
echo "Your name is: ". $myName. PHP_EOL;

