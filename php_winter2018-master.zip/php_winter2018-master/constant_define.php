<?php

define ('TEST', 'This is a test !', true);
echo TEST . PHP_EOL;
echo 'TEST' . PHP_EOL;
echo test;