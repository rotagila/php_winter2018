<?php

function c1(){
    echo "This is controller 1".PHP_EOL;
}


// This file should contain your first controller.