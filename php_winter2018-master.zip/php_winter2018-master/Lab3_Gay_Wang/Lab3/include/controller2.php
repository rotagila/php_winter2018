<?php

function c2(){
    echo "This is controller 2".PHP_EOL;
}


// This file should contain your second controller.