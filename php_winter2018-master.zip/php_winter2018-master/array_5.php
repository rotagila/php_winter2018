<?php

$cards = array(
		'red'    => array(1, 2, 3, 4),
		'blue'   => array(1, 2, 3, 4),
		'green'  => array(1, 2, 3, 4),
		'yellow' => array(1, 2, 3, 4)
);

var_dump($cards);