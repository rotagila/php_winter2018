#!/bin/bash
curl -sS https://apigility.org/install | php
exit