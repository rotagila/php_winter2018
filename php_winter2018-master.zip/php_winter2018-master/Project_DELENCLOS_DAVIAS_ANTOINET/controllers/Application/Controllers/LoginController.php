<?php

namespace Application\Controllers;

session_start();

use \Ascmvc\AbstractApp;
use \Ascmvc\Mvc\Controller;
use Application\Services\CrudProductsService;
use Application\Services\CrudProductsServiceTrait;
use Application\Models\Entity\Products;

class LoginController extends Controller {

    use CrudProductsServiceTrait;

    function session_obliterate()
    {
        $_SESSION = array();
        setcookie(session_name(),'', time() - 3600, '/');
        setcookie('loggedin', '', time() - 3600, '/');
        session_destroy();   // Destroy session data in storage.
        session_unset();     // Unset $_SESSION variable for the runtime.
        $validSession = FALSE;
        return $validSession;

    }

    function session_secure_init()
    {
        session_set_cookie_params(4200);
        $validSession = TRUE;

        if (!defined('OURUNIQUEKEY')) {

            define('OURUNIQUEKEY', 'phpi');

        }

        // Avoid session prediction.
        $sessionname = OURUNIQUEKEY;

        if (session_name() != $sessionname) {

            session_name($sessionname);

        } else {

            session_name();

        }

        // Start session.
        session_start();

        if ((!isset($_COOKIE['loggedin']) && isset($_SESSION['LOGGEDIN']))
            ^ (isset($_COOKIE['loggedin']) && !isset($_SESSION['LOGGEDIN']))) {

            $validSession = FALSE;

        }

        if ($validSession == TRUE) {

            // Avoid session fixation.
            if (!isset($_SESSION['INITIATED'])) {

                session_regenerate_id();
                $_SESSION['INITIATED'] = TRUE;

            }

            if (!isset($_SESSION['CREATED'])) {

                $_SESSION['CREATED'] = time();

            }

            if (time() - $_SESSION['CREATED'] > 3600) {

                // Session started more than 60 minutes ago.
                session_regenerate_id();    // Change session ID for the current session an invalidate old session ID.
                $_SESSION['CREATED'] = time();  // Update creation time.

            }

            // Avoid session hijacking.
            $useragent = $_SERVER['HTTP_USER_AGENT'];

            $useragent .= OURUNIQUEKEY;

            if (isset($_SESSION['HTTP_USER_AGENT'])) {

                if ($_SESSION['HTTP_USER_AGENT'] != md5($useragent)) {

                    $validSession = FALSE;

                }

            } else {

                $_SESSION['HTTP_USER_AGENT'] = md5($useragent);

            }

            // Avoid session fixation in case of an inactive session.
            if ($validSession == TRUE && isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > 3600) {

                // Last request was more than 60 minutes ago.
                $validSession = FALSE;

            } else {

                $_SESSION['LAST_ACTIVITY'] = time(); // Update last activity timestamp.

            }

        }

        return $validSession;
    }

    function verifyUser($username, $password)
    {

        $con = mysqli_connect("localhost:3306","lightmvcuser", "testpass", "lightmvctestdb");

        /* Crée une requête préparée */
        $stmt = $con->prepare("SELECT password FROM users where username = ?");

        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($hash);
        $stmt->fetch();

        $bool = password_verify($password,$hash);

        $stmt->free_result();
        $stmt->close();
        $con->close();
        return $bool;
    }


    public static function config(AbstractApp &$app)
    {
        IndexController::config($app);
    }

    public function predispatch()
    {
        $em = $this->serviceManager->getRegisteredService('em1');

        $this->serviceManager->addRegisteredService('CrudProductService', new CrudProductsService(new Products(), $em));

        $this->setCrudProducts($this->serviceManager->getRegisteredService('CrudProductService'));
    }

    public function indexAction()
    {
        $this->view['bodyjs'] = 1;

        $this->viewObject->assign('view', $this->view);

        if($_SESSION['LOGGEDIN'] == TRUE)
        {
            $this->viewObject->assign('loggedin', $_SESSION['LOGGEDIN']);
        }

        $this->viewObject->display('login_index.tpl');
    }

    public function loginAction()
    {
        $this->view['bodyjs'] = 1;

        $loginCheck = FALSE;
        $validSession = FALSE;
        $postLoginForm = TRUE;

        if (isset($_COOKIE['loggedin'])) {
            if ($validSession === FALSE) {

                $validSession = $this->session_secure_init();

            }

            //  Check for cookie tampering.
            if ($validSession === TRUE && isset($_SESSION['LOGGEDIN'])) {

                $postLoginForm = FALSE;

            } else {

                $validSession = $this->session_obliterate();

                $errorMessage = 3;

                $postLoginForm = TRUE;

            }

            // Cookie login check done.
            $loginCheck = TRUE;

        }

        if(isset($_POST['submit']))
        {
            if ($validSession === FALSE) {

                $validSession = $this->session_secure_init();

            }

            $username = (string) $_POST['username'];
            $password = (string) $_POST['password'];

            if (!ctype_alpha($username))
            {
                $username = preg_replace("/[^_a-zA-Z0-9]+/", "", $username);
            }

            $password = preg_replace("/[^_a-zA-Z0-9]+/", "", $password);
            if($this->verifyUser($username, $password))
            {
                $this->view['verify'] = 1;

                if ($validSession === TRUE) {

                    //  Check for cookie tampering.
                    if (isset($_SESSION['LOGGEDIN'])) {

                        $validSession = $this->session_obliterate();
                        $errorMessage = 3;
                        $postLoginForm = TRUE;

                    } else {

                        setcookie('loggedin', TRUE, time()+ 4200, '/');
                        $_SESSION['LOGGEDIN'] = TRUE;
                        $_SESSION['REMOTE_USER'] = $username;
                        $postLoginForm = FALSE;

                    }

                } else {

                    $validSession = $this->session_obliterate();
                    $errorMessage = 3;
                    $postLoginForm = TRUE;

                }

            }else
            {
                $this->view['verify'] = 0;
                $validSession = $this->session_obliterate();
                $errorMessage = 1;
                $postLoginForm = TRUE;
            }

            $loginCheck = TRUE;
        }

        $this->viewObject->assign('view', $this->view);
        $this->viewObject->assign('loggedin', $_SESSION['LOGGEDIN']);
        $this->viewObject->display('login_index.tpl');
    }

    public function logoutAction()
    {
        $this->session_obliterate();

        $this->view['bodyjs'] = 1;

        $this->viewObject->assign('view', $this->view);

        $this->viewObject->display('index_index.tpl');
    }
}