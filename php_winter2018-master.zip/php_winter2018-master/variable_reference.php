<?php

$a = 1;

$b = &$a;

$b =  2;

var_dump($a);