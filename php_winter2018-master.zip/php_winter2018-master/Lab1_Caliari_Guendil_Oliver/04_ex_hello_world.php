<?php

// "Hello World!" program

/*
 * On two lines:
 * print "Hello World!" to the screen (STDOUT),
 * print a greetings message with your first name in it.
 *
 * Your first name must be stored in a variable.
 *
 */
$name = "Axel";
echo "Hello World!" . PHP_EOL;
echo "Welcome! I'm " . $name;
