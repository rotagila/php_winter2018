<?php

// This file should contain your first controller.

class controller1
{
   public function __construct()
   {
       echo "This is controller 1!";
   }
}