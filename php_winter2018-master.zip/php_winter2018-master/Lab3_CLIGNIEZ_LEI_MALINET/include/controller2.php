<?php

// This file should contain your second controller.

class controller2
{
    public function __construct()
    {
        echo "This is controller 2!";
    }
}