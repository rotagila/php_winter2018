<?php

$array = array('2' => 1,3);

$array['b'] = 4;

$array[] = 2;

var_dump($array);