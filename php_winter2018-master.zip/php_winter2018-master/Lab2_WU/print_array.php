<?php

// Create an array
$arr = array(1,2,3,4,5,6);
// Print the array to screen using a foreach loop
foreach ($arr as $value){
    echo $value . PHP_EOL;
}