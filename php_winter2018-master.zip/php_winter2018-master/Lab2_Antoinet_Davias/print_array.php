<?php

// Create an array

$array = ['Apple', 'Pear', 'Blackberry', 'Orange'];

// Print the array to screen using a foreach loop

foreach($array as $fruit)
{
    echo $fruit . PHP_EOL;
}