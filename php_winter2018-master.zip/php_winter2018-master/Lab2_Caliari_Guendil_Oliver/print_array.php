<?php

// Create an array

// Print the array to screen using a foreach loop

$array = [1, 2, 3, 4];

foreach($array as $value)
    echo $value . PHP_EOL;