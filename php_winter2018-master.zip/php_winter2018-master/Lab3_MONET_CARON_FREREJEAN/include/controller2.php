<?php

// This file should contain your second controller.



function fct1 ()
{
    echo "this is a little hello of fct1 from controller2.php";
}

function fct2 ()
{
    echo "this is a little hello of fct2 from controller2.php";
}
