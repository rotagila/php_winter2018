<?php

// This file should contain your first controller.


function fct1 ()
{
    echo "this is a little hello of fct1 from controller1.php";
}

function fct2 ()
{
    echo "this is a little hello of fct2 from controller1.php";
}

