# LightMVC Test
A basic MVC application for educational purposes.

## HOWTO

* Add your database configuration to config/config.local.php,
* Load the included test database data/db.sql,
* Run the 'composer install' command,
* Load the application in your favorite browser.

NOTE: Please make sure that the server can write to the cache/, logs/ and templates_c/ folders!

### Have a lot of fun! :)