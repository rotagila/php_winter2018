<?php

namespace Application\Models\Traits;

trait DoctrineTrait
{
    protected $em;

    /**
     * @return mixed
     */
    public function getEm()
    {
        return $this->em;
    }

    /**
     * @param mixed $em
     */
    public function setEm($em)
    {
        $this->em = $em;
    }
}