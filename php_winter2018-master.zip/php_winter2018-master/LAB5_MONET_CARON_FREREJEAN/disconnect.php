
<?php
session_start();

unset($_SESSION['user']);

echo "You have been disconnected ! See you"


?>