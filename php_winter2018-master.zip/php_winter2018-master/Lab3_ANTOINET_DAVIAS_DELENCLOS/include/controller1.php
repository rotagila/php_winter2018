<?php

// This file should contain your first controller.

function ctrl(){
    echo 'Controller1';
}