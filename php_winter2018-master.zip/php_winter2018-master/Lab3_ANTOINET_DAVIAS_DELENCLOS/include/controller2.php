<?php

// This file should contain your second controller.
function ctrl(){
    echo 'Controller2';
}