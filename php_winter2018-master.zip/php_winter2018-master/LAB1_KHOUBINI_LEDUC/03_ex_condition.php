<?php

$valueA = 3;
$valueB = 3;

if($valueA >$valueB) {
    echo "$valueA is greater than $valueB <br />" . PHP_EOL;
} elseif($valueA == $valueB) {
    echo "$valueA is  equal to $valueB <br />" . PHP_EOL;
}