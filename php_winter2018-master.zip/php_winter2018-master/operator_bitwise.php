<?php

$a = 33;
$b = $a << 2;
$b = $b - 10;

var_dump($a, $b);

echo chr($a);
echo chr($b);