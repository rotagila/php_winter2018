<?php
$a = 1;
$b = 2;

if ($a == 1 ^ $b == 2) {
    echo 'True' . PHP_EOL;
} else {
    echo 'False' . PHP_EOL;
}
