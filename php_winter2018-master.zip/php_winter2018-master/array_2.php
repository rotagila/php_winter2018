<?php

$myArray = explode(" ", 'Programming in PHP is fun!');

// $myArray = array('Programming', 'in', 'PHP', 'is', 'fun!');

// $myArray = ['Programming', 'in', 'PHP', 'is', 'fun!'];

/*$myArray[] = 'Programming';
$myArray[] = 'in';
$myArray[] = 'PHP';
$myArray[] = 'is';
$myArray[] = 'fun!';*/

//echo $myArray[2];

var_dump($myArray);
