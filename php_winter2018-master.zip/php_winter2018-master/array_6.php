<?php

$fruits = [
    "fruits"  => array("a" => "orange", "b" => "banana", "c" => "apple", "Pierre"),
    "numbers" => array(1, 2, 3, 4, 5, 6),
    "holes"   => array("first", 5 => "second", "third")
];

var_dump($fruits);