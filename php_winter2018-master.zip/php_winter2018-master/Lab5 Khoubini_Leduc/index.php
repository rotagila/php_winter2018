<?php

// Create a simple login form that will authenticate and authorize a user.