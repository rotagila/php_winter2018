<?php

$valueA = 5;
$valueB = 3;

if($valueA > $valueB) {
    echo 'ValueA is greater than ValueB <br />' . PHP_EOL;
} elseif($valueA == $valueB) {
    echo 'ValueA is equal to ValueB <br />' . PHP_EOL;
}