<?php

$a = 1;

// may print either 3 or 4
echo $a + $a++;