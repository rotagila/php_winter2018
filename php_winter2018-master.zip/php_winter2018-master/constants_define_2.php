<?php

define('TEST', 'This is a test!', true);

echo TEST . '<br />';

echo test;