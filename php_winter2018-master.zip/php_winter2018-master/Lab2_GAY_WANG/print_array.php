<?php

// Create an array

$array[] = "First";
$array[] = "Second";
$array[] = "Third";
$array[] = "Fourth";
$array[] = "Fifth";
$array[] = "Sixth";
$array[] = "Seventh";

foreach ($array as $str) {
    echo $str . PHP_EOL;
}

// Print the array to screen using a foreach loop