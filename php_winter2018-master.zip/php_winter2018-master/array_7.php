<?php

$arr1 = array("one", 5 => "two", "three");

$arr2 = array("a" => "one", "b" => "two", "three");

var_dump($arr1, $arr2);